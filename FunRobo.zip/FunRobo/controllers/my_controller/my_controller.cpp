#include <webots/Robot.hpp>
#include <webots/Motor.hpp>
#include <webots/DistanceSensor.hpp>

using namespace webots;

int main() {
    Robot robot;
    int timeStep = (int)robot.getBasicTimeStep();
    double maxSpeed = 6.28;
    
    Motor *leftMotor = robot.getMotor("motor_1");
    Motor *rightMotor = robot.getMotor("motor_2");
    leftMotor->setPosition(INFINITY);
    rightMotor->setPosition(INFINITY);
    leftMotor->setVelocity(0.0);
    rightMotor->setVelocity(0.0);
    
    DistanceSensor *leftSensor = robot.getDistanceSensor("sensor_left");
    leftSensor->enable(timeStep);
    
    DistanceSensor *rightSensor = robot.getDistanceSensor("sensor_right");
    rightSensor->enable(timeStep);
    
    bool cornerDetected = false; // Köşe tespiti için bir bayrak değişkeni
    
    while (robot.step(timeStep) != -1) {
        double leftDistance = leftSensor->getValue();
        double rightDistance = rightSensor->getValue();
        bool obstacleAvoided = true;
        bool leftObstacle = (leftDistance < 1000);
        bool rightObstacle = (rightDistance < 1000);
        leftObstacle = (leftDistance < 1000);
        rightObstacle = (rightDistance < 1000);
       if(leftObstacle || rightObstacle){
         obstacleAvoided = false;
       }
        if ((leftObstacle && rightObstacle) || !obstacleAvoided ){ // Her iki tarafta da engel varsa
            if (!cornerDetected) { // Köşeye ilk defa takıldıysa
                leftMotor->setVelocity(-maxSpeed * 0.2);  // Sola doğru geriye dön
                rightMotor->setVelocity(-maxSpeed * 0.2); // Sağa doğru geriye dön
                robot.step(1000);  // 1000 zaman adımı boyunca geriye hareket et
                leftMotor->setVelocity(maxSpeed * 0.2);  // Sol motoru ileriye döndür
                rightMotor->setVelocity(-maxSpeed * 0.2); // Sağ motoru geriye döndür
                robot.step(1000);  // 1000 zaman adımı boyunca dön
                cornerDetected = true; // Köşe tespiti yapılıyor
                 
            } else if(obstacleAvoided) { // Köşeden çıkmak için dönme hareketini sürdür
                leftMotor->setVelocity(-maxSpeed * 0.2);  // Sola doğru geriye dön
                rightMotor->setVelocity(maxSpeed * 0.2); // Sağa doğru ileriye dön
                robot.step(1000);  // 500 zaman adımı boyunca dön
                obstacleAvoided=true;
            }
        } else { // Engel yoksa
            leftMotor->setVelocity(maxSpeed * 0.5);  // Daha hızlı sola dön
            rightMotor->setVelocity(maxSpeed * 0.5); // Daha hızlı sağa dön
            cornerDetected = false; // Köşe tespiti sıfırlanıyor
        }
    }
    
    return 0;
}